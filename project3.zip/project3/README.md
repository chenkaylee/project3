# Instructions
The redis commands that you would use to interact with your specific Redis structures. 
Example: I will keep a sorted set with the most viewed products in my application. Therefore I need:

Initialize:
FLUSHALL
Get the list of most viewed items for user duto_guerra:
ZREVRANGE mostViewed:duto_guerra 0 -1
When user duto_guerra visits produc p1234 one more time:
ZINCRBY mostViewed:duto_guerra 1 p1234
etc...
Describe the commands for all your use cases. Make sure to include all CRUD operations

