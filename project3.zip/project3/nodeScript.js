const express = require('express');
const redis = require('redis');

// Connect to the local Redis server.
const client = redis.createClient();

const app = express();
const PORT = 3000;

client.on('error', (err) => {
  console.log('Redis Client Error', err);
});

client.on('connect', () => {
  console.log('Connected to Redis...');
});

// Increment product views
app.get('/product/view/:productId', (req, res) => {
  const { productId } = req.params;
  client.zincrby('popularProducts', 1, productId, (err, response) => {
    if (err) {
      console.error('Error incrementing product view count:', err);
      res.status(500).send('Error incrementing product view count');
    } else {
      console.log(`Product ${productId} view count incremented`);
      res.send(`Product ${productId} view count incremented, new score: ${response}`);
    }
  });
});

// Get top N popular products
app.get('/products/top/:count', (req, res) => {
  const { count } = req.params;
  client.zrevrange('popularProducts', 0, count - 1, 'WITHSCORES', (err, response) => {
    if (err) {
      console.error('Error retrieving top products:', err);
      res.status(500).send('Error retrieving top products');
    } else {
      console.log('Top products retrieved:', response);
      res.send(response);
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});