// Implementing the real-time popular products functionality

// Initialization
FLUSHALL

// Create/Add a new product variant to the popular products sorted set (assuming it starts with 0 views/sales)
ZADD popularProducts 0 variant123

// Read/Get the list of top N most viewed/sold product variants
ZREVRANGE popularProducts 0 N-1 WITHSCORES

// Update/Increment the number of views/sales when a product variant is viewed or sold
ZINCRBY popularProducts 1 variant123

// Delete/Remove a product variant from the popular products sorted set
ZREM popularProducts variant123

// Find the rank of a specific product variant based on views/sales
ZRANK popularProducts variant123

// Get the score (number of views/sales) of a specific product variant
ZSCORE popularProducts variant123

// Get a range of product variants by their score (number of views/sales), for example, products with views/sales between 50 and 100
ZRANGEBYSCORE popularProducts 50 100 WITHSCORES

// If you need to adjust the score for a product variant directly (e.g., correcting an error)
ZADD popularProducts NEW_SCORE variant123

// To remove product variants that fall below a certain popularity threshold (e.g., less than 10 views/sales)
ZREMRANGEBYSCORE popularProducts -inf 9

// To limit the size of the sorted set to only keep the top X popular products
ZREMRANGEBYRANK popularProducts 0 -X
